SELECT 
*
FROM 
{{ source('landing','reviews')}}