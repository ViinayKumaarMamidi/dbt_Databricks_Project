SELECT 
*
FROM 
{{ source('landing','users')}}