SELECT 
*
FROM 
{{ source('landing','orders')}}