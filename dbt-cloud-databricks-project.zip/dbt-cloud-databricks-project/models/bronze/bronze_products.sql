SELECT 
*
FROM {{ source('landing','products')}}